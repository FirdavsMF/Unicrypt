import React from 'react';
import Abouts from '../components/about/Abouts';
export default function abouts() {
    return (
        <div>
            <Abouts/>
        </div>
    )
}
