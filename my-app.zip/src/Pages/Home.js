import React from 'react'

import Homes from '../components/homes/Homes'
export default function Home() {
    return (
        <div>
            <>
         <Homes/>
        
            </>
        </div>
    )
}
