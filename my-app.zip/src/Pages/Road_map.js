import React from 'react'
import Road_map from '../components/road_map/Road_map'
export default function road_map() {
    return (
        <div>
            <Road_map/>
        </div>
    )
}
