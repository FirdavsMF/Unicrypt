import React from 'react';
import Blog_single from '../components/blog_single/Blog_single';
export default function blog_single() {
    return (
        <div>
            <Blog_single/>
        </div>
    )
}
