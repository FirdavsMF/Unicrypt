import React from 'react';
import Team from '../components/team/Team';
export default function team() {
    return (
        <div>
           |<Team /> 
        </div>
    )
}
