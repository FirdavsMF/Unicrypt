import React from 'react';
import Faq from '../components/faq/Faq';
export default function faq() {
    return (
        <div>
            <Faq/>
        </div>
    )
}
