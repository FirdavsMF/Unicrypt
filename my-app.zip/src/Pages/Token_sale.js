import React from 'react';
import Token_sale from '../components/token_sale/Token_sale';
export default function token_sale() {
    return (
        <div>
            <Token_sale/>
        </div>
    )
}
